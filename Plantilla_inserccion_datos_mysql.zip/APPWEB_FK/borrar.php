<?php
print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';
include_once("apertura-base.php"); 

$Cod_Per = $_GET["Cod_Per"]; 
 
print "<h2>Se va a borrar la persona cuyo codigo es:</h2>";
print "<h1>$Cod_Per</h1>";
print "<h2>Estas seguro?</h2>";
print '<a href="borrar2.php?Cod_Per=' . $Cod_Per.'"><img src="check.ico" /></a>';
print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
print '<a href="modificar datos.php" target="_self"><img src="atras.png" /></a>';
print "</body>";
?>