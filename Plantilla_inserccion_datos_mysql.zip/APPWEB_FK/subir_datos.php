<head>
	<style type="text/css">
		*{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
		url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}

		h1 {color:#FF0606}
	
		h2 {color:#ff0000}
	
		option {color:#FF0000}
	    
		strong {color:#EFFF01}
		
		a {color:#EFFF01}
		
		* {text-align: center;}

		p {color:#ff0000}

		p a { color:#ffffff; }

		p span a { color:#17E94C; }
	</style>
</head>

<body bgcolor="000000">
	<form bgcolor="000000" action="add_reg.php" method="post">
		<strong>Cod_Per</strong> <input type="text" name="cod_per"><br></br>
		<strong>NIF:</strong> <input type="text" name="nif"></input><br></br>
		<strong>Nombre:</strong> <input type="text" name="nombre"></input><br></br>
		<strong>Ap1:</strong> <input type="text" name="ap1"></input><br></br>
		<strong>Ap2:</strong> <input type="text" name="ap2"></input><br></br>
		<strong>Edad:</strong> <input type="text" name="edad"></input><br></br>
		<strong>Idiomas:</strong> <input type="text" name="idiomas"></input><br></br>
		<strong>Cod_Dep:</strong>  <?php
$servidor="qvt331.iesluisvelez.org";
$usuario="qvt331";
$password="GRUPO6gbd";
$bd="qvt331";
$tabla="DEPARTAMENTOS";
$conex=mysql_connect($servidor,$usuario,$password);
mysql_select_db($bd);
$query=mysql_query("select * from $tabla",$conex);
echo "<select name=\"cod_dep\">\n";
while ($reg=mysql_fetch_array($query)) {
echo "<option value=\"$reg[2]\">$reg[2]</option>\n";
}
echo "</select>";
?>
		<input type="submit" name="enviar" value="Subir!">
	</form>
</body>