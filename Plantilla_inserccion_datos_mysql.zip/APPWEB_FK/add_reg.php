﻿<?php
$cod_per  =$_POST['cod_per'];
$nif =$_POST['nif'];
$nombre =$_POST['nombre'];
$ap1 =$_POST['ap1'];
$ap2 =$_POST['ap2'];
$edad =$_POST['edad'];
$idiomas =$_POST['idiomas'];
$cod_dep =$_POST['cod_dep'];


print
		'<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}


		</style>
		';
print '<body bgcolor="000000">';

         $link = mysql_connect("qvt331.iesluisvelez.org","qvt331","GRUPO6gbd");
        mysql_select_db("qvt331",$link);

        // Con esta sentencia SQL insertaremos los datos en la base de datos

	
		
		$insertar="INSERT INTO PERSONAS VALUES ($cod_per,'$nif','$nombre','$ap1','$ap2',$edad,'$idiomas',$cod_dep)";
		
$query = mysql_query($insertar); 
$af=mysql_affected_rows();

		print "<h1>Se va a lanzar contra la BD el comando:</h1>";
print "<br></br>";
print "<h2><strong>$insertar</strong></h2><br /><<hr />";

        // Ahora comprobaremos que todo ha ido correctamente
        $my_error = mysql_error($link);
print $insertar;
        if (!empty($my_error)) 
			{      echo "<h1>Ha habido un error al insertar los valores. $my_error</h1>";  }
		else {   echo "<h1>Los datos han sido introducidos satisfactoriamente</h1>"; 
echo "<h2>Se ha insertado <h1><strong>$af</strong></h1> <h2>registro</h2></h2><br />";		}
		echo '<a href="subir_datos.php" style="color:#33BB3B" target="_self"><img src="atras.png" ALT="align box" ALIGN=MIDDLE border="0"></a><br/><br/>';
     
print '</body>';
?>