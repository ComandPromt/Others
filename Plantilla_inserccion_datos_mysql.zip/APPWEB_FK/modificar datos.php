<?php
include("apertura-base.php"); 
$ssql = "select * from PERSONAS"; 
$query = mysql_query($ssql); 

print
		'<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
td {color:#FF0000}
 a {color:#EFFF01}
		</style>
		';
print '<body bgcolor="000000">';
print
 '<table align="center" border="5">
	<tr>
	
	<td><strong>Cod_Per</strong></td>
    <td><strong>NIF</strong></td>
	<td><strong>Nombre</strong></td>
	<td><strong>Ap1</strong></td>
	<td><strong>Ap2</strong></td>
	<td><strong>Edad</strong></td>
	<td><strong>Idiomas</strong></td>
	<td><strong>Cod_Dep</strong></td>
	 </tr>
 ';
 
while($fila = mysql_fetch_array($query)) { 
	
		
	print "
	<tr>
	<td><a>$fila[Cod_Per]</a></td>
    <td><a>$fila[NIF]</a></td>
	<td><a>$fila[Nombre]</a></td>
	<td><a>$fila[Ap1]</a></td>
	<td><a>$fila[Ap2]</a></td>
	<td><a>$fila[Edad]</a></td>
	<td><a>$fila[Idiomas]</a></td>
	<td><a>$fila[Cod_Dep]</a></td>
	
	";
	
print'	<td><a href="editar.php?Cod_Per=' . $fila['Cod_Per'].'&NIF='.$fila['NIF'] .'&Nombre='.$fila['Nombre'] .'&Ap1='.$fila['Ap1'].'&Ap2='.$fila['Ap2'].'&Edad='.$fila['Edad'].'&Idiomas='.$fila['Idiomas'].'&Cod_Dep='.$fila['Cod_Dep'].'">Editar</a></td>';
echo '  <td><a href="borrar.php?Cod_Per=' . $fila['Cod_Per'].'">Borrar</a></td>';
print '  </tr>';
	
		
	
} 
print '</table>';
print "<br></br>"; 
print '<a style="display:scroll;position:fixed;bottom:5px;right:5px;" href="#" title="Subir arriba"><img src="up.png" /></a>';
print '</body>';
?> 