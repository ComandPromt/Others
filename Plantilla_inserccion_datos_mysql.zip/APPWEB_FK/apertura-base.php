<?php   
$conexion=mysql_connect("qvt331.iesluisvelez.org","qvt331","GRUPO6gbd")or die(mysql_error());  
mysql_select_db("qvt331")or die(mysql_error()); 
?> 