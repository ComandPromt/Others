<?php include("apertura-base.php"); 
print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';

$Cod_Per = $_POST['Cod_Per']; 
$NIF = $_POST['NIF']; 
$Nombre = $_POST['Nombre'];
$Ap1 = $_POST['Ap1'];
$Ap2 = $_POST['Ap2'];
$Edad = $_POST['Edad'];
$Idiomas = $_POST['Idiomas'];
$Cod_Dep = $_POST['Cod_Dep'];


$sql = "UPDATE  PERSONAS SET `Cod_Per`='$Cod_Per',`NIF`='$NIF',`Nombre`='$Nombre',`Ap1`='$Ap1',`Ap2`='$Ap2',`Edad`='$Edad',`Idiomas`='$Idiomas',`Cod_Dep`='$Cod_Dep' WHERE `Cod_Per`='$Cod_Per'";

if (mysql_query($sql)) { 
$af=mysql_affected_rows();
print "<h2>Se va a lanzar contra la BD el comando:</h2>";
print "<br></br>";
print "<h1><strong>$sql</strong></h1><br /><hr />";
echo "<h2>Se ha editado <h1><strong>$af</strong></h1> <h2>registro</h2></h2><br />";
} else { 
echo "<h1>Error de actualizaci&oacute;n</h1>"; 
} 

print '<a href="modificar datos.php" target="_self"><img src="atras.png" /></a>';
mysql_close($conexion);
?> 