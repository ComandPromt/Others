<?php  
// Incluimos la conexión.
include_once("apertura-base.php"); 
// Pasamos el id por $_GET desde la url. 
$Cod_Per = $_GET["Cod_Per"]; 
$NIF = $_GET["NIF"];
$Nombre = $_GET["Nombre"];
$Ap1 = $_GET["Ap1"];
$Ap2 = $_GET["Ap2"];
$Edad = $_GET["Edad"];
$Idiomas = $_GET["Idiomas"];
$Cod_Dep = $_GET["Cod_Dep"];

?> 
<strong><a href="modificar datos.php" target="_self"><img src="atras.png" /></a></strong>
<br></br>
<body bgcolor="000000">
<form action="update-campo.php" method="post">  
<style type="text/css">

		* {text-align: center;}

	 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
strong {color:#EFFF01}
		</style>
<strong>Cod_Per:</strong>
<br /> 
<input type="text" name="Cod_Per" value="<?php echo $Cod_Per?>"readonly="readonly">
<br/><br/> 

<strong>NIF:</strong>
<br /> 
<input type="text" name="NIF" value="<?php echo $NIF;?>"> 
<br/><br/> 

<strong>Nombre:</strong>
<br /> 
<input type="text" name="Nombre" value="<?php echo $Nombre;?>"> 
<br/><br/> 

<strong>Ap1:</strong>
<br /> 
<input type="text" name="Ap1" value="<?php echo $Ap1;?>"> 
<br/><br/> 

<strong>Ap2:</strong>
<br /> 
<input type="text" name="Ap2" value="<?php echo $Ap2;?>"> 
<br/><br/> 

<strong>Edad:</strong>
<br /> 
<input type="text" name="Edad" value="<?php echo $Edad;?>"> 
<br/><br/> 

<strong>Idiomas:</strong>
<br /> 
<input type="text" name="Idiomas" value="<?php echo $Idiomas;?>"> 
<br/><br/> 

<strong>Cod_Dep:</strong>
<br /> 
<input type="text" name="Cod_Dep" value="<?php echo $Cod_Dep;?>"> 
<br/><br/> 

<input type="submit" value="Actualizar"> 
</form>
</body>