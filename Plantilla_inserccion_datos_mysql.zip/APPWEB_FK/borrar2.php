<?php
$conexion=mysql_connect("qvt331.iesluisvelez.org","qvt331","GRUPO6gbd")or die(mysql_error());  
mysql_select_db("qvt331")or die(mysql_error()); 

$Cod_Per = $_GET["Cod_Per"]; 

print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';


$borrar="DELETE FROM PERSONAS WHERE Cod_Per = '$Cod_Per'";
$query = mysql_query($borrar); 
$af=mysql_affected_rows();
print "<h2>Se va a lanzar contra la BD el comando:</h2>";
print "<br></br>";
print "<h1><strong>$borrar</strong></h1><br /><<hr />";
echo "<h2>Se ha borrado <h1><strong>$af</strong></h1> <h2>registro</h2></h2><br />";
print '<a href="modificar datos.php" target="_self"><img src="atras.png" /></a>';
print '</body>';
?>
