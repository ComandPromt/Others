<?php
include_once("apertura-base.php"); 

$id_pais = $_GET["id_pais"];

print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';


$borrar="DELETE FROM paises WHERE id_pais = '$id_pais'";
$query = mysql_query($borrar); 
$af=mysql_affected_rows();
print "<h2>Se va a lanzar contra la BD el comando:</h2>";
print "<br></br>";
print "<h1><strong>$borrar</strong></h1><br /><hr />";
echo "<h2>Se ha borrado <h1><strong>$af</strong></h1> <h2>registro</h2></h2><br />";
print '<a href="update-con-seleccion.php" target="_self"><img src="atras.png" /></a>';
print '</body>';
?>
