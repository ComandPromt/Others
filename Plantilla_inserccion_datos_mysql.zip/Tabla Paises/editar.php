<?php  
// Incluimos la conexión.
include_once("apertura-base.php"); 
// Pasamos el id por $_GET desde la url. 
$id_pais = $_GET["id_pais"]; 
$nom_pais = $_GET["nom_pais"];
$id_continente = $_GET["id_continente"]; 
?> 
<strong><a href="update-con-seleccion.php" target="_self"><img src="atras.png" /></a></strong>
<br></br>
<body bgcolor="000000">
<form action="update-campo.php" method="post">  
<style type="text/css">

		* {text-align: center;}

	 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
strong {color:#EFFF01}
		</style>
<strong>Id:</strong>
<br /> 
<input type="text" name="id_pais" value="<?php echo $id_pais?>"readonly="readonly">

<br/><br/> 
<strong>Nombre:</strong>

<br /> 
<input type="text" name="nom_pais" value="<?php echo $nom_pais;?>"> 
<br/><br/> 
<strong>Continente:</strong>

<br /> 
<input type="text" name="id_continente" value="<?php echo $id_continente;?>"> 
<br/><br/> 
<input type="submit" value="Actualizar"> 
</form>
</body>