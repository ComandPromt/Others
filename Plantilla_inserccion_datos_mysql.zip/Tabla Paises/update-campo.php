<?php include("apertura-base.php"); 
print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';

$id_pais = $_POST['id_pais']; 
$nom_pais = $_POST['nom_pais']; 
$id_continente = $_POST['id_continente']; 
$sql = "UPDATE  `paises`.`paises` SET `id_pais`='$id_pais',`nom_pais`='$nom_pais',`id_continente`='$id_continente' WHERE `id_pais`='$id_pais'";

if (mysql_query($sql)) { 
$af=mysql_affected_rows();
print "<h2>Se va a lanzar contra la BD el comando:</h2>";
print "<br></br>";
print "<h1><strong>$sql</strong></h1><br /><hr />";
echo "<h2>Se ha editado <h1><strong>$af</strong></h1> <h2>registro</h2></h2><br />";
} else { 
echo "<h1>Error de actualizaci&oacute;n</h1>"; 
} 

print '<a href="update-con-seleccion.php" target="_self"><img src="atras.png" /></a>';
mysql_close($conexion);
print "</body>";
?> 