<?php
print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';
include_once("apertura-base.php"); 

$id_pais = $_GET["id_pais"];

print "<h2>Se va a borrar el Pais con el id:</h2>";
print "<h1>$id_pais</h1>";
print "<h2>Est&aacute;s seguro?</h2>";
print '<a href="borrar2.php?id_pais=' . $id_pais.'"><img src="check.ico" /></a>';
print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
print '<a href="update-con-seleccion.php" target="_self"><img src="atras.png" /></a>';
print "</body>";
?>