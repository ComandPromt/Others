﻿<?php
$id_pais  =$_POST['id_pais'];
$nom_pais =$_POST['nom_pais'];
$id_continente =$_POST['id_continente'];

print
		'<body bgcolor="000000">
		<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
		* {text-align: center;}
		h1,a {color: red;}
		h2 {color: yellow;}
		</style>
		';
    // Primero comprobamos que ningún campo esté vacío y que todos los campos existan.
    if(isset($_POST['id_pais']) && !empty($_POST['id_pais']) &&
    isset($_POST['nom_pais']) && !empty($_POST['nom_pais']) &&
	isset($_POST['id_continente']) && !empty($_POST['id_continente'])
	)
	
        // Si entramos es que todo se ha realizado correctamente

        $link = mysql_connect("localhost","root","root");
        mysql_select_db("paises",$link);

        // Con esta sentencia SQL insertaremos los datos en la base de datos
        mysql_query("
		INSERT INTO `paises`.`paises` (`id_pais` ,`nom_pais` ,`id_continente`)
		VALUES ('$id_pais','$nom_pais','$id_continente')",$link);
		
		

        // Ahora comprobaremos que todo ha ido correctamente
        $my_error = mysql_error($link);

        if (!empty($my_error)) 
			{      echo "<h1>Ha habido un error al insertar los valores. $my_error</h1>";  }
		else {   echo "<h1>Los datos se han sido introducidos satisfactoriamente</h1>";   }
		echo '<a href="subir_archivo.php" style="color:#33BB3B" target="_self"><img src="atras.png" ALT="align box" ALIGN=MIDDLE border="0"></a><br/><br/>';
     
print '</body>';
?>