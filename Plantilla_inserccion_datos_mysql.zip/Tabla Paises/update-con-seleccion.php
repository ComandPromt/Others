<?php
include("apertura-base.php"); 
$ssql = "select id_pais,nom_pais,id_continente from paises "; 
$query = mysql_query($ssql); 

print
		'<style type="text/css">
 *{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}
td {color:#FF0000}
 a {color:#EFFF01}
		</style>
		';
print '<body bgcolor="000000">';
print
 '<table align="center" border="5">
	<tr>
	
	<td><strong>ID Pa&iacute;s</strong></td>
    <td><strong>Pa&iacute;s</strong></td>
	<td><strong>Continente</strong></td>
	<td><strong>Editar</strong></td>
	<td><strong></strong></td>
	 </tr>
 ';
 
while($fila = mysql_fetch_array($query)) { 
	
		
	print "
	<tr>
	<td><a>$fila[id_pais]</a></td>
    <td><a>$fila[nom_pais]</a></td>
	<td><a>$fila[id_continente]</a></td>
	";
print'	<td><a href="editar.php?id_pais=' . $fila['id_pais'].'&nom_pais='.$fila['nom_pais'] .'&id_continente='.$fila['id_continente'] . '">Editar</a></td>';
echo '  <td><a href="borrar.php?id_pais=' . $fila['id_pais'].'">Borrar</a></td>';
print '  </tr>';
	
		
	
} 
print '</table>';
print "<br></br>"; 
print '<a style="display:scroll;position:fixed;bottom:5px;right:5px;" href="#" title="Subir arriba"><img src="up.png" /></a>';
print '</body>';
?> 