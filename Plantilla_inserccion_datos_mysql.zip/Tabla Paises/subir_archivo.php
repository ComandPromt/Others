<head>
	<style type="text/css">
		*{cursor: url("http://downloads.totallyfreecursors.com/cursor_files/flameblue.ani"), 
		url("http://downloads.totallyfreecursors.com/thumbnails/flameblue.gif"), auto;}

		h1 {color:#FF0606}
	
		h2 {color:#ff0000}
	
		option {color:#FF0000}
	    
		strong {color:#EFFF01}
		
		a {color:#EFFF01}
		
		* {text-align: center;}

		p {color:#ff0000}

		p a { color:#ffffff; }

		p span a { color:#17E94C; }
	</style>
</head>

<body bgcolor="000000">
	<form bgcolor="000000" action="add_reg.php" method="post">
		<strong>ID Pa&iacute;s:</strong> <input type="text" name="id_pais"><br></br>
		<strong>Nombre:</strong> <input type="text" name="nom_pais"></input><br></br>
		<strong>Continente:</strong>
			<?php
				$servidor="localhost";
				$usuario="root";
				$password="root";
				$bd="paises";
				$tabla="continentes";
				$conex=mysql_connect($servidor,$usuario,$password);
				mysql_select_db($bd);
				$query=mysql_query("select * from $tabla order by nom_continente",$conex);
				echo "<select name=\"id_continente\">\n";
				while ($reg=mysql_fetch_array($query)) { 
				echo "<option value=\"$reg[0]\">$reg[1]</option>\n";
				}
				echo "</select>";
				?>
		<br></br>
				<input type="submit" name="enviar" value="Subir!">
	</form>
</body>