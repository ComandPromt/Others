 <?php   
$conexion=mysql_connect("localhost","root","root")or die(mysql_error());  
mysql_select_db("paises")or die(mysql_error()); 
?> 